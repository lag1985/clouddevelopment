import React from 'react'
import './App.css'

import Card from './components/Card.jsx'

export default props => (
  <div>
    <Card Title="Cloud Development" color="#9C0F5F">Nomes e RMs</Card>
  </div>
)