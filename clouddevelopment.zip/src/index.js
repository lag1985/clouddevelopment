import React from 'react'
import ReactDOM from 'react-dom'
import './index.css'

import App from './App.jsx'

ReactDOM.render(
  <App></App>,
  document.getElementById('root')
);

